<html>
<head>
<title>Sistem Temu Kembali</title>
<!--<link  href="../jw.png" rel="shortcut icon" type="image/png" />-->
<style>
h2 {
    background-size: 60px 40px;
	background-color: #c3d0ef;
}
</style>
</head>
<body>
<h2 align=center><br>Sistem Temu Kembali Informasi<br><br></h2>
<hr>
<div align=center>
| <a href="koneksi.php">Koneksi</a> |
<a href="tf.php">Term Frequency</a> |
<a href="idf.php">Invers Document Frequency</a> |
<a href="tfidf.php">TF.IDF</a> |
</div>
<hr/>
</body>
</html>
